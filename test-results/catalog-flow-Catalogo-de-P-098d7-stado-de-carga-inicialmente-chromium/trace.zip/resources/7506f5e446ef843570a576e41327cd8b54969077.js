(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_11mj2gn._.js","static/chunks/0umx_next_dist_compiled_next-devtools_index_03ipq8m.js","static/chunks/0umx_next_dist_compiled_react-dom_0xq.2u~._.js","static/chunks/0umx_next_dist_compiled_react-server-dom-turbopack_0ekihwe._.js","static/chunks/0umx_next_dist_compiled_0oski57._.js","static/chunks/0umx_next_dist_client_0xjgfo3._.js","static/chunks/0umx_next_dist_0wbatg9._.js","static/chunks/0i4a_@swc_helpers_cjs_0hvz.20._.js"],
    source: "entry"
});
